#include <GLFW/glfw3.h>
#include "linmath.h"
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <iostream>
#include <vector>
#include <windows.h>
#include <time.h>
#include <math.h>

using namespace std;

const float DEG2RAD = 3.14159f / 180;

void processInput(GLFWwindow* window);

// Brick types
enum BRICKTYPE { REFLECTIVE, DESTRUCTABLE };
enum ONOFF { ON, OFF };

class Brick
{
public:
    float red, green, blue;
    float x, y, width;
    BRICKTYPE brick_type;
    ONOFF onoff;
    int hits = 0; // To track hits for destructible bricks

    Brick(BRICKTYPE bt, float xx, float yy, float ww, float rr, float gg, float bb)
    {
        brick_type = bt; x = xx; y = yy; width = ww; red = rr; green = gg; blue = bb;
        onoff = ON;
    }

    void drawBrick()
    {
        if (onoff == ON)
        {
            double halfside = width / 2;
            glColor3d(red, green, blue);
            glBegin(GL_POLYGON);
            glVertex2d(x + halfside, y + halfside);
            glVertex2d(x + halfside, y - halfside);
            glVertex2d(x - halfside, y - halfside);
            glVertex2d(x - halfside, y + halfside);
            glEnd();
        }
    }
};

class Circle
{
public:
    float red, green, blue;
    float radius;
    float x, y;
    float speed = 0.03f;
    int direction;

    Circle(float xx, float yy, float rr, int dir, float rad, float r, float g, float b)
    {
        x = xx;
        y = yy;
        radius = rad;
        red = r;
        green = g;
        blue = b;
        direction = dir;
    }

    void CheckCollision(Brick* brk)
    {
        if (brk->onoff == OFF) return;

        if ((x > brk->x - brk->width && x < brk->x + brk->width) &&
            (y > brk->y - brk->width && y < brk->y + brk->width))
        {
            if (brk->brick_type == REFLECTIVE)
            {
                direction = GetRandomDirection();
            }
            else if (brk->brick_type == DESTRUCTABLE)
            {
                brk->hits++;
                if (brk->hits == 1)
                {
                    brk->red = 1; brk->green = 0; brk->blue = 0; // Change color on first hit
                }
                else if (brk->hits >= 2)
                {
                    brk->onoff = OFF; // Destroy after 2 hits
                }
            }
        }
    }

    int GetRandomDirection()
    {
        return (rand() % 8) + 1;
    }

    void MoveOneStep()
    {
        // Move
        if (direction == 1 || direction == 5 || direction == 6) y -= speed; // up
        if (direction == 3 || direction == 7 || direction == 8) y += speed; // down
        if (direction == 2 || direction == 5 || direction == 7) x += speed; // right
        if (direction == 4 || direction == 6 || direction == 8) x -= speed; // left

        // Bounce off walls with physics
        if (y > 1 - radius)
        {
            if (direction == 3) direction = 1;
            if (direction == 7) direction = 6;
            if (direction == 8) direction = 5;
        }
        if (y < -1 + radius)
        {
            if (direction == 1) direction = 3;
            if (direction == 5) direction = 7;
            if (direction == 6) direction = 8;
        }
        if (x > 1 - radius)
        {
            if (direction == 2) direction = 4;
            if (direction == 5) direction = 6;
            if (direction == 7) direction = 8;
        }
        if (x < -1 + radius)
        {
            if (direction == 4) direction = 2;
            if (direction == 6) direction = 5;
            if (direction == 8) direction = 7;
        }
    }

    void DrawCircle()
    {
        glColor3f(red, green, blue);
        glBegin(GL_POLYGON);
        for (int i = 0; i < 360; i++) {
            float degInRad = i * DEG2RAD;
            glVertex2f((cos(degInRad) * radius) + x, (sin(degInRad) * radius) + y);
        }
        glEnd();
    }
};

vector<Circle> world;

vector<Brick> bricks;

Brick paddle(REFLECTIVE, 0, -0.8f, 0.3f, 0.5f, 0.5f, 1.0f);

int main(void)
{
    srand(time(NULL));

    if (!glfwInit()) {
        exit(EXIT_FAILURE);
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
    GLFWwindow* window = glfwCreateWindow(480, 480, "8-2 Assignment", NULL, NULL);
    if (!window) {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    // Setup bricks in a grid pattern
    for (float x = -0.8f; x <= 0.8f; x += 0.4f)
    {
        for (float y = 0.6f; y >= 0.2f; y -= 0.2f)
        {
            bricks.push_back(Brick(DESTRUCTABLE, x, y, 0.15f, (rand() % 100) / 100.0f, (rand() % 100) / 100.0f, (rand() % 100) / 100.0f));
        }
    }

    while (!glfwWindowShouldClose(window))
    {
        // Setup View
        float ratio;
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        ratio = width / (float)height;
        glViewport(0, 0, width, height);
        glClear(GL_COLOR_BUFFER_BIT);

        processInput(window);

        // Move paddle
        if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS && paddle.x > -0.85)
            paddle.x -= 0.02f;
        if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS && paddle.x < 0.85)
            paddle.x += 0.02f;

        // Ball collision with paddle
        for (int i = 0; i < world.size(); i++)
        {
            world[i].CheckCollision(&paddle);
        }

        // Ball-to-brick collision, move, draw
        for (int i = 0; i < world.size(); i++)
        {
            for (auto& b : bricks)
                world[i].CheckCollision(&b);

            world[i].MoveOneStep();
            world[i].DrawCircle();
        }

        // Ball-to-ball collision
        for (int i = 0; i < world.size(); i++)
        {
            for (int j = i + 1; j < world.size(); j++)
            {
                float dx = world[i].x - world[j].x;
                float dy = world[i].y - world[j].y;
                float distance = sqrt(dx * dx + dy * dy);
                if (distance < world[i].radius + world[j].radius)
                {
                    world[i].radius += world[j].radius * 0.5f;
                    world.erase(world.begin() + j);
                    break;
                }
            }
        }

        // Draw bricks
        for (auto& b : bricks)
            b.drawBrick();

        // Draw paddle
        paddle.drawBrick();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}

void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS)
    {
        double r, g, b;
        r = (rand() % 100) / 100.0f;
        g = (rand() % 100) / 100.0f;
        b = (rand() % 100) / 100.0f;

        // Random slight offset to prevent instant collision
        float startX = ((rand() % 20) - 10) / 100.0f; // between -0.1 and 0.1
        float startY = ((rand() % 20) - 10) / 100.0f;

        Circle B(startX, startY, 0.2f, (rand() % 8) + 1, 0.05f, r, g, b);
        world.push_back(B);
    }
}
