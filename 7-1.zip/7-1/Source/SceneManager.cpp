// scenemanager.cpp - Ang's mug scene with Tom's lighting and materials
#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// Shader uniform variable names
namespace {
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

// Constructor: initializes shader manager and shape loader
SceneManager::SceneManager(ShaderManager* pShaderManager) {
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

// Destructor: safely cleans up memory
SceneManager::~SceneManager() {
	if (m_basicMeshes != nullptr) {
		delete m_basicMeshes;
		m_basicMeshes = nullptr;
	}
}

// Loads texture image and generates OpenGL texture from file
bool SceneManager::CreateGLTexture(const char* filename, std::string tag) {
	int width, height, colorChannels;
	stbi_set_flip_vertically_on_load(true);
	unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);
	if (image) {
		GLuint textureID;
		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// Texture wrapping and filtering settings
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// Assign pixel format based on channels
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else {
			stbi_image_free(image);
			return false;
		}

		glGenerateMipmap(GL_TEXTURE_2D);
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0);

		// Store texture info
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	return false;
}

// Binds all loaded textures to OpenGL texture units
void SceneManager::BindGLTextures() {
	for (int i = 0; i < m_loadedTextures; i++) {
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

// Sends transformation matrix to shader
void SceneManager::SetTransformations(glm::vec3 scaleXYZ, float Xrot, float Yrot, float Zrot, glm::vec3 pos) {
	glm::mat4 modelView = glm::translate(pos) *
		glm::rotate(glm::radians(Zrot), glm::vec3(0, 0, 1)) *
		glm::rotate(glm::radians(Yrot), glm::vec3(0, 1, 0)) *
		glm::rotate(glm::radians(Xrot), glm::vec3(1, 0, 0)) *
		glm::scale(scaleXYZ);
	m_pShaderManager->setMat4Value("model", modelView);
}

// Sends solid color to shader (used when no texture)
void SceneManager::SetShaderColor(float r, float g, float b, float a) {
	m_pShaderManager->setIntValue(g_UseTextureName, false);
	m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(r, g, b, a));
}

// Binds a texture to the shader using its tag
void SceneManager::SetShaderTexture(std::string tag) {
	int slot = FindTextureSlot(tag);
	if (slot != -1) {
		m_pShaderManager->setIntValue(g_UseTextureName, true);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, slot);
	}
}

// Finds texture slot for a given tag
int SceneManager::FindTextureSlot(std::string tag) {
	for (int i = 0; i < m_loadedTextures; ++i) {
		if (m_textureIDs[i].tag == tag) return i;
	}
	return -1;
}

// Sets material properties in shader based on tag
void SceneManager::SetShaderMaterial(std::string tag) {
	for (auto& mat : m_objectMaterials) {
		if (mat.tag == tag) {
			m_pShaderManager->setVec3Value("material.ambientColor", mat.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", mat.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", mat.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", mat.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", mat.shininess);
			break;
		}
	}
}

// Loads texture(s) used in the scene
void SceneManager::LoadSceneTextures() {
	CreateGLTexture("Textures/mugtext.jpg", "mug");
	BindGLTextures();
	m_pShaderManager->setVec2Value("UVscale", glm::vec2(1.0f, 1.0f));
}

// Defines materials for objects in the scene
void SceneManager::DefineObjectMaterials() {
	// Metal material for mug
	OBJECT_MATERIAL metal;
	metal.tag = "metal";
	metal.ambientColor = glm::vec3(0.2f);
	metal.ambientStrength = 0.3f;
	metal.diffuseColor = glm::vec3(0.2f);
	metal.specularColor = glm::vec3(0.5f);
	metal.shininess = 22.0f;
	m_objectMaterials.push_back(metal);

	// Wood material for the plane
	OBJECT_MATERIAL wood;
	wood.tag = "wood";
	wood.ambientColor = glm::vec3(0.1f);
	wood.ambientStrength = 0.2f;
	wood.diffuseColor = glm::vec3(0.2f);
	wood.specularColor = glm::vec3(0.1f);
	wood.shininess = 0.3f;
	m_objectMaterials.push_back(wood);
}

// Sets up lighting (directional + point) in the scene
void SceneManager::SetupSceneLights() {
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// Directional light (e.g., sunlight)
	m_pShaderManager->setVec3Value("directionalLight.direction", glm::vec3(-0.5f, -1.0f, -0.3f));
	m_pShaderManager->setVec3Value("directionalLight.ambient", glm::vec3(0.02f));
	m_pShaderManager->setVec3Value("directionalLight.diffuse", glm::vec3(1.0f));
	m_pShaderManager->setVec3Value("directionalLight.specular", glm::vec3(1.0f));
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);

	// Set camera position for specular reflection
	m_pShaderManager->setVec3Value("viewPosition", glm::vec3(0.0f, 0.0f, 10.0f));

	// Point light (adds fill light to reduce darkness)
	m_pShaderManager->setVec3Value("pointLights[0].position", glm::vec3(2.0f, 5.0f, 2.0f));
	m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.5f));
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(0.9f));
	m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(0.6f));
	m_pShaderManager->setFloatValue("pointLights[0].constant", 1.0f);
	m_pShaderManager->setFloatValue("pointLights[0].linear", 0.09f);
	m_pShaderManager->setFloatValue("pointLights[0].quadratic", 0.032f);
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);
}

// Prepares the scene with lights, materials, textures, and mesh geometry
void SceneManager::PrepareScene() {
	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();

	// Load mesh shapes
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadPlaneMesh();
}

// Renders all objects with materials, textures, and lighting
void SceneManager::RenderScene() {
	BindGLTextures();

	// Draw the textured wooden plane (floor or desk)
	SetTransformations({ 20,1,10 }, 0, 0, 0, { 0,0,0 });
	SetShaderColor(1, 1, 1, 1); // fallback in case no texture
	SetShaderMaterial("wood");
	m_basicMeshes->DrawPlaneMesh();

	// Draw mug body (tapered cylinder)
	SetTransformations({ 1.5f, 3.0f, 1.5f }, 180, 0, 0, { 0.1f, 3.25f, 0.0f });
	SetShaderTexture("mug");
	SetShaderMaterial("metal");
	m_basicMeshes->DrawTaperedCylinderMesh();

	// Draw mug handle (torus)
	SetTransformations({ 0.4f, .6f, 0.4f }, 180, 0, 90, { 1.55f, 2.25f, 0.0f });
	SetShaderTexture("mug");
	SetShaderMaterial("metal");
	m_basicMeshes->DrawTorusMesh();
}
